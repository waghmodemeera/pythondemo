from django.shortcuts import render

# Create your views here.

def ml_show(r):
    return render(r,'technical_jobs/ML.html')