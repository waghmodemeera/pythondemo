from django.apps import AppConfig


class TechnicalJobsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'technical_jobs'
