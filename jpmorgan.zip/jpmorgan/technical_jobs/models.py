from django.db import models

# Create your models here.
class Employee(models.Model):
    name = models.CharField(max_length=45)
    age = models.IntegerField()
    email = models.EmailField()
    mobile = models.IntegerField()

class Dept(models.Model):
    dept_id = models.IntegerField(primary_key=True)
    dept_name = models.CharField(max_length=25)